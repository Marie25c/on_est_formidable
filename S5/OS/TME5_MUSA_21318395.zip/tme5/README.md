TME5
MUSA Marie-Christine
21318395

1.  code : arbre.c
    exec :
        make arbre
        ./arbre <niveau>

2.  code : mini_shell.c
    exec :
        make mini_shell
        ./mini_shell <commande>

3.  J'ai pas réussi, je crois avoir eu des soucis avec execv
    code : mini_shell2.c 
    exec :
        make mini_shell2
        ./mini_shell2 <commande>

4. Ajouter au deux mini_shell :) avec un wait avec ressource ^^

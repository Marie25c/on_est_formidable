#include <stdio.h>
#include <stdlib.h>
#include <time.h>


int main(){

    long int i =0;
    while(i<5000000000){
        //printf("%d ",i);
        i++;
    }
    return 0;

}
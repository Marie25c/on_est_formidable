#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int max(int* liste,int taille);
void InitTab(int *tab,int size);
void PrintTab(int *tab,int size);
int SumTab(int *tab, int size);
int MinSumTab(int *min, int *tab, int size);